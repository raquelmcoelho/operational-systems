#ifndef SINCOS_H
#define SINCOS_H

void printTrigValues();
void printSin();
void printCos();

#endif // SINCOS_H
