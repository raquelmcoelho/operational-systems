#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <../include/sin_cos.h>
#include <../include/sin_cos_g.h>


void question1() {
    printTrigValues();
}

void question2() {
    writeAndPlot();
}


int main() {
    question2();
    return 0;
}
